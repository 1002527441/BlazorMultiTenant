﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSAAS.Application.Dtos
{
    public class TenantDto
    {
       
        public virtual Guid TenantId { get; set; }     
        public virtual string Name { get; set; }    
        public virtual string Host { get; set; }

        public virtual string ConnectionString { get; set; }
        public virtual DateTimeOffset CreatedTime { get; set; }
    }
}
