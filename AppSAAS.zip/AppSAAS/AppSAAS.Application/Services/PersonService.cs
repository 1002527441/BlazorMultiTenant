﻿using AppSAAS.Core.DbContextLocators;
using AppSAAS.Core.Entites;
using Furion.DatabaseAccessor;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSAAS.Application.Services
{

    [DynamicApiController]
    public class PersonService:ITransient
    {

        private readonly IRepository<Person> _repository;

        public PersonService(IRepository<Person> repository)
        {
            _repository = repository;
        }



        public void Add(Person person)
        {
            
            _repository.InsertNowAsync(person);
        }


        public List<Person> Get()
        {
            return _repository.AsQueryable().ToList();
        }
    }
}
