﻿using AppSAAS.Core.Entites;

[DynamicApiController]
public class UserService : ITransient
{

    private readonly IRepository<User> _repository;

    public UserService(IRepository<User> repository)
    {
        _repository = repository;
    }



    public void Add(User person)
    {

        _repository.InsertNowAsync(person);
    }


    public List<User> Get()
    {
        return _repository.AsQueryable().ToList();
    }
}

