﻿using AppSAAS.Application.Dtos;
using AppSAAS.Core.Entites;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSAAS.Application.Services
{

    [DynamicApiController]
    public class TenantService:ITransient
    {
        private readonly IRepository<Tenant, MultiTenantDbContextLocator> _repository;

        public TenantService(IRepository<Tenant, MultiTenantDbContextLocator> repository)
        {
            _repository = repository;
        }


        public List<TenantDto> Get()
        {
            var lstEntities =  _repository.AsQueryable().ToList();
            return lstEntities.Adapt<List<TenantDto>>();
        }

        public string GetConnectStringByname(string name)
        {
            var entity = _repository.AsQueryable()
                .AsQueryable().FirstOrDefault(x => x.Name == name);

            if (entity == null) { return null; }

            return entity.ConnectionString;
        }


    }
}
