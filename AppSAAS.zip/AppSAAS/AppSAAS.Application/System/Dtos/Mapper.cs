﻿namespace AppSAAS.Application
{
    public class Mapper : IRegister
    {
        public void Register(TypeAdapterConfig config)
        {
        }
    }
}