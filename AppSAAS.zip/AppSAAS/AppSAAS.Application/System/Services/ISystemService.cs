﻿namespace AppSAAS.Application
{
    public interface ISystemService
    {
        string GetDescription();
    }
}