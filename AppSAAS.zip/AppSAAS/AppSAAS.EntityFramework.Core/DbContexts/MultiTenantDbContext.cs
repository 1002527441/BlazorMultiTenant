﻿using Furion.DatabaseAccessor;
using Microsoft.EntityFrameworkCore;

namespace AppSAAS.EntityFramework.Core
{
    [AppDbContext("Sqlite1", DbProvider.Sqlite)]
    public class MultiTenantDbContext : AppDbContext<MultiTenantDbContext, MultiTenantDbContextLocator>
    {
        public MultiTenantDbContext(DbContextOptions<MultiTenantDbContext> options) : base(options)
        {
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);
        }


    }
}