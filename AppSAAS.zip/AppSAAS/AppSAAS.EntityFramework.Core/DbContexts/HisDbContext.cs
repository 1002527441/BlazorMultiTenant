﻿using AppSAAS.Core.DbContextLocators;
using AppSAAS.Core.Entites;
using Furion;
using Furion.DatabaseAccessor;
using Furion.Logging;
using Furion.RemoteRequest;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using SQLitePCL;
using System;
using System.Net.NetworkInformation;
using System.Threading;

namespace AppSAAS.EntityFramework.Core
{
    
    public class HisDbContext : AppDbContext<HisDbContext>, IMultiTenantOnDatabase
    {
        private readonly IConfiguration _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public DbSet<Person> Person { get; set; }
        public DbSet<User> User { get; set; }

        public HisDbContext(IConfiguration configuration, IHttpContextAccessor httpContextAccessor, DbContextOptions<HisDbContext> options) : base(options)
        {
            _configuration = configuration;
            _httpContextAccessor = httpContextAccessor;
        }

        public string GetDatabaseConnectionString()
        {
            var migrationDbname = DbName.Db002;

            var connectionString = getConnectionString();

            Console.WriteLine(connectionString);            

            return connectionString?? migrationDbname;
        }


        private string? getConnectionString()
        {

            var connectionString = base.Tenant?.ConnectionString;
            return connectionString;

        }






        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {

            var connectionString = GetDatabaseConnectionString();

            optionsBuilder.UseSqlite(connectionString, options =>
            {
                options.MigrationsAssembly("AppSAAS.Database.Migrations");
            });

            base.OnConfiguring(optionsBuilder);
        }
    }
}