﻿using AppSAAS.Core.DbContextLocators;
using Furion;
using Furion.DatabaseAccessor;
using Microsoft.Extensions.DependencyInjection;

namespace AppSAAS.EntityFramework.Core
{
    public class Startup : AppStartup
    {
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddDatabaseAccessor(options =>
            {
                //options.CustomizeMultiTenants();
                options.AddDb<HisDbContext>();
                options.AddDbPool<MultiTenantDbContext, MultiTenantDbContextLocator>();
            }, "AppSAAS.Database.Migrations");
        }
    }
}