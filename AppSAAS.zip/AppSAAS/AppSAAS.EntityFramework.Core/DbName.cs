﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSAAS.EntityFramework.Core
{

    //数据库的名字须要跟
    public class DbName
    {
        public const string Db001 = "Data Source=./App01.db;";
        public const string Db002 = "Data Source=./App02.db;";
        public const string Db003 = "Data Source=./App03.db;";
        public const string Db004 = "Data Source=./App04.db;";
    }
}
