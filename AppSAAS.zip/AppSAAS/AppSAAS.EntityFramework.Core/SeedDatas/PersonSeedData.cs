﻿using AppSAAS.Core.Entites;
using Furion.DatabaseAccessor;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;

namespace AppSAAS.EntityFramework.Core.SeedDatas;

public class PersonSeedData : IEntitySeedData<Person>
{
    public IEnumerable<Person> HasData(DbContext dbContext, Type dbContextLocator)
    {
        return new List<Person>
        {
            new Person
            {
                Id= 1,
                CreatedTime= DateTime.Parse("2023/4/13 17:14"),
                UpdatedTime=null,
                Name = "user01",
                Address  = "Address01"
            },
            new Person
            {
                Id= 2,
                CreatedTime= DateTime.Parse("2023/4/13 17:14"),
                UpdatedTime=null,
                Name = "user02",
                Address  = "Address02"
            }
        };
    }
}
