﻿using Furion.DatabaseAccessor;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSAAS.EntityFramework.Core
{
    public class TenantSeedData : IEntitySeedData<Tenant, MultiTenantDbContextLocator>
    {
        public IEnumerable<Tenant> HasData(DbContext dbContext, Type dbContextLocator)
        {
            return new List<Tenant>
            {
                new Tenant
                {
                    TenantId = Guid.Parse("383AFB88-F519-FFF8-B364-6D563BF3687F"),
                    Name = "公司01",
                    Host = "localhost:44313",                    
                    CreatedTime = DateTime.Parse("2020-10-06 20:19:07"),
                    ConnectionString = "Data Source=./App01.db" // 配置连接字符串,
                    
                    
                },
                new Tenant
                {
                    TenantId = Guid.Parse("C5798CB6-16D6-0F42-EB56-59C695353BC0"),
                    Name = "公司02",
                    Host = "localhost:44314",
                    CreatedTime = DateTime.Parse("2020-10-06 20:20:32"),
                    ConnectionString = "Data Source=./App02.db" // 配置连接字符串
                }
            };
        }
    }
}
