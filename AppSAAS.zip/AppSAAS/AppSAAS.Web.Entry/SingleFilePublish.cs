﻿using Furion;
using System.Reflection;

namespace AppSAAS.Web.Entry
{
    public class SingleFilePublish : ISingleFilePublish
    {
        public Assembly[] IncludeAssemblies()
        {
            return Array.Empty<Assembly>();
        }

        public string[] IncludeAssemblyNames()
        {
            return new[]
            {
            "AppSAAS.Application",
            "AppSAAS.Core",
            "AppSAAS.EntityFramework.Core",
            "AppSAAS.Web.Core"
        };
        }
    }
}